import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:video_trimmer/video_trimmer.dart';

void main() => runApp(const ShortsRajaApp());

class ShortsRajaApp extends StatelessWidget {
  const ShortsRajaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ShortsRaja ULTRA PRO',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF101116),
      ),
      home: const EditorHome(),
    );
  }
}

class EditorHome extends StatefulWidget {
  const EditorHome({super.key});
  @override
  State<EditorHome> createState() => _EditorHomeState();
}

class _EditorHomeState extends State<EditorHome> {
  VideoPlayerController? controller;
  final Trimmer _trimmer = Trimmer();
  double _start = 0, _end = 0, speed = 1.0, aspect = 9/16;
  String projectName = 'Naya Project';
  String filter = 'Normal';
  String overlayText = '';
  bool isExporting = false;

  Future<void> importVideo() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.video);
    if (r == null || r.files.single.path == null) return;
    final file = File(r.files.single.path!);
    await _trimmer.loadVideo(videoFile: file);
    controller?.dispose();
    final c = VideoPlayerController.file(file);
    await c.initialize();
    c.addListener(() { if (mounted) setState(() {}); });
    setState(() {
      controller = c;
      projectName = r.files.single.name;
      _start = 0;
      _end = c.value.duration.inMilliseconds.toDouble();
    });
  }

  Future<void> exportVideo() async {
    if (controller == null) return;
    setState(() => isExporting = true);
    await _trimmer.saveTrimmedVideo(
      startValue: _start,
      endValue: _end,
      onSave: (out) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export Ho Gaya: $out')),
        );
        setState(() => isExporting = false);
      },
    );
  }

  ColorFilter? getFilter() {
    if (filter == 'BW') {
      return const ColorFilter.matrix(<double>[
        0.2126, 0.7152, 0.0722, 0, 0,
        0.2126, 0.7152, 0.0722, 0, 0,
        0.2126, 0.7152, 0.0722, 0, 0,
        0, 0, 0, 1, 0,
      ]);
    }
    if (filter == 'Sepia') {
      return const ColorFilter.matrix(<double>[
        0.393, 0.769, 0.189, 0, 0,
        0.349, 0.686, 0.168, 0, 0,
        0.272, 0.534, 0.131, 0, 0,
        0, 0, 0, 1, 0,
      ]);
    }
    return null;
  }

  @override
  void dispose() { controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final video = controller;
    return Scaffold(
      appBar: AppBar(
        title: const Text('ShortsRaja ULTRA PRO'),
        backgroundColor: const Color(0xFF191923),
        actions: [
          IconButton(icon: const Icon(Icons.folder_open), onPressed: importVideo),
          IconButton(icon: const Icon(Icons.save), onPressed: exportVideo),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              const Icon(Icons.movie_creation),
              const SizedBox(width: 8),
              Expanded(child: Text(projectName, overflow: TextOverflow.ellipsis)),
              ElevatedButton(onPressed: importVideo, child: const Text('Video Jodo')),
            ]),
          ),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: aspect,
                child: Container(
                  color: Colors.black,
                  child: video != null && video.value.isInitialized
                      ? Stack(children: [
                          ColorFiltered(
                            colorFilter: getFilter() ?? const ColorFilter.mode(Colors.transparent, BlendMode.dst),
                            child: VideoPlayer(video),
                          ),
                          if (overlayText.isNotEmpty)
                            Center(child: Text(overlayText, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold))),
                        ])
                      : const Center(child: Text('Apna Video Chuno')),
                ),
              ),
            ),
          ),
          if (video != null && video.value.isInitialized)
            Column(children: [
              TrimViewer(
                trimmer: _trimmer,
                duration: video.value.duration,
                editorProperties: TrimEditorProperties(circleSize: 8, borderWidth: 3),
                onChangeStart: (v) => _start = v,
                onChangeEnd: (v) => _end = v,
                onChangePlaybackState: (p) { if (p) video.play(); else video.pause(); },
              ),
              IconButton(
                iconSize: 48,
                onPressed: () { video.value.isPlaying ? video.pause() : video.play(); setState(() {}); },
                icon: Icon(video.value.isPlaying ? Icons.pause_circle : Icons.play_circle),
              ),
              Text(isExporting ? 'Export ho raha hai...' : 'Trim: ${(_start/1000).toStringAsFixed(1)}s - ${(_end/1000).toStringAsFixed(1)}s'),
            ]),
          Container(
            padding: const EdgeInsets.all(12),
            color: const Color(0xFF191923),
            child: Column(children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                OutlinedButton(onPressed: () => setState(() => aspect = 9/16), child: const Text('9:16')),
                OutlinedButton(onPressed: () => setState(() => aspect = 16/9), child: const Text('16:9')),
                OutlinedButton(onPressed: () => setState(() => aspect = 1), child: const Text('1:1')),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                OutlinedButton(onPressed: () => setState(() => filter = 'Normal'), child: const Text('Normal')),
                OutlinedButton(onPressed: () => setState(() => filter = 'BW'), child: const Text('B&W')),
                OutlinedButton(onPressed: () => setState(() => filter = 'Sepia'), child: const Text('Sepia')),
              ]),
              Slider(value: speed, min: 0.25, max: 2, divisions: 7, label: '${speed}x', onChanged: (v) async { setState(() => speed = v); await controller?.setPlaybackSpeed(v); }),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: exportVideo, child: const Text('EXPORT VIDEO'))),
            ]),
          ),
        ],
      ),
    );
  }
}
